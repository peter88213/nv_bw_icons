"""A monochrome icon set for novelibre.

Requires Python 3.7+
Copyright (c) Peter Triesberger
For further information see https://github.com/peter88213/nv_bw_icons
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
import os
from pathlib import Path
import shutil

from abc import ABC, abstractmethod
from pathlib import Path



class SubController:

    def disable_menu(self):
        pass

    def enable_menu(self):
        pass

    def lock(self):
        pass

    def on_close(self):
        pass

    def on_open(self):
        pass

    def on_quit(self):
        pass

    def unlock(self):
        pass

import tkinter as tk


class PluginBase(ABC, SubController):
    VERSION = ''
    API_VERSION = ''
    DESCRIPTION = ''
    URL = ''
    HELP_SITE = None
    HELP_PAGE = None

    def __init__(self):
        self.filePath = None
        self.isActive = True
        self.isRejected = False

        self._icon = None

    @abstractmethod
    def install(self, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller

    def uninstall(self):
        pass

    def _add_help_menu_entry(self, label):

        def open_help():
            self._ctrl.helpService.open_help_page(
                self.HELP_PAGE,
                site=self.HELP_SITE
            )

        self._ui.helpMenu.add_command(
            label=label,
            image=self._icon,
            compound='left',
            command=open_help,
        )

    def _get_icon(self, fileName):
        if self._ctrl.get_preferences().get('large_icons', False):
            size = 24
        else:
            size = 16
        try:
            homeDir = str(Path.home()).replace('\\', '/')
            iconPath = f'{homeDir}/.novx/icons/{size}'
            icon = tk.PhotoImage(file=f'{iconPath}/{fileName}')
        except:
            icon = None
        return icon


class Plugin(PluginBase):
    VERSION = '5.3.1'
    API_VERSION = '5.63'
    DESCRIPTION = 'Monochrome icon set'
    URL = 'https://github.com/peter88213/nv_bw_icons'
    HELP_SITE = 'https://peter88213.github.io/nv_bw_icons'
    HELP_PAGE = 'help'

    def install(self, model, view, controller):
        super().install(model, view, controller)
        try:
            homeDir = str(Path.home()).replace('\\', '/')
            self.iconPath = f'{homeDir}/.novx/nv_bw_icons'
        except:
            self.iconPath = None
        if not os.path.isdir(self.iconPath):
            raise UserWarning(
                'Icons not found:'
                f'"{os.path.normpath(self.iconPath)}".'
            )


        self._add_help_menu_entry('nv_bw_icons plugin help')

    def uninstall(self):
        if self.iconPath is not None:
            shutil.rmtree(self.iconPath, ignore_errors=True)
            self.iconPath = None

