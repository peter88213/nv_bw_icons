# Credits

The Icons are based on the [Eva Icons](https://akveo.github.io/eva-icons/#/), published under the [MIT License](http://www.opensource.org/licenses/mit-license.php). 
Some of the shapes were modified for this plugin by the maintainer. 